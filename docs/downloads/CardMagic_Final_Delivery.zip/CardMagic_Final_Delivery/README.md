# Card Magic Final Runtime Package

## Entry points

- [Project documentation](CardMagic_Project_Documentation_EN_Final_Code.docx)
- [Arduino source](TwoDC/TwoDC.ino)
- [Processing source](Processing/ExternalCamera_Control_v2.pde)
- [Wekinator project](wekinator/WekinatorProject/WekinatorProject.wekproj)

The source files are unchanged copies of the supplied final files.

## Startup

1. Upload `TwoDC/TwoDC.ino` to Arduino Uno R3, then close Serial Monitor.
2. Open the supplied Wekinator project, retaining its directory structure.
3. In Processing, install Video and oscP5. Update `ARDUINO_PORT` and verify `CAMERA_INDEX` (currently 1).
4. Open the PDE sketch. If Processing requests a matching sketch folder, allow it to create `ExternalCamera_Control_v2` and keep the PDE inside it.
5. Run Processing and wait for READY and live camera frames. Press C to confirm the camera.
6. Click Run in Wekinator. Focus Processing and use S to shuffle, D to scan, and X or Esc to stop. Stop before switching modes.

## Final behaviour

S: motor 1 starts immediately; motor 2 starts after 600 ms. D: motor 1 runs 80 ms on / 1000 ms off; motor 2 stays off. Class 1 continues. Class 2 triggers three new complete feeding pulses, then TARGET_DONE and the message "this is your card". T simulates detection during scanning.

Serial: 9600 baud. OSC input: /wek/inputs, 6448, 400 brightness values. OSC output: /wek/outputs, localhost:12000, one output, two classes.

Some Processing status messages still describe one final pulse; Arduino executes three. This package preserves the source rather than silently editing it. No hardware execution or model accuracy testing was performed while assembling this package.
